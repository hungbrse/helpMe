package model.dao.book;

import model.entity.Book;

import java.util.List;

public interface BookDao {

    List<Book> findAll();
    Boolean addNewBook(Book book);
    Boolean updateBook(Book book);
    Book findBookById(int id);
    void deleteBookById(int id);
}
