package model.entity;

public class Book {
    private int id;
    private String title;
    private String author;
    private double price;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Book(int id, double price, String author, String title) {
        this.id = id;
        this.price = price;
        this.author = author;
        this.title = title;
    }

    public Book() {
    }
}
