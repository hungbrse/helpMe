package model.service.book;

import model.dao.book.BookDao;
import model.entity.Book;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService implements BookServiceImpl{
    private BookDao bookDao;
    @Override
    public List<Book> findAll() {
          return bookDao.findAll();
    }

    @Override
    public Boolean addNewBook(Book book) {
        return bookDao.addNewBook(book);
    }

    @Override
    public Boolean updateBook(Book book) {
        return null;
    }

    @Override
    public Book findBookById(int id) {
        return null;
    }

    @Override
    public void deleteBookById(int id) {

    }
}
